
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}


var bedroomButton = document.getElementsByClassName('bedroomButton');
var childrenButton  = document.getElementsByClassName('childrenButton');
var toiletButton = document.getElementsByClassName('toiletButton');
var drawingRoomButton = document.getElementsByClassName('drawingRoomButton');
var kitchenButton  = document.getElementsByClassName('kitchenButton');
var officeButton  = document.getElementsByClassName('officeButton');
var showrromButton = document.getElementsByClassName('showroomButton');
